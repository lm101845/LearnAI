This code is borrowed from the official PyTorch example repository (https://github.com/pytorch/examples/tree/main/word_language_model).

We've added some Chinese comments, serving as hints for you to adapt the code for a classification task.
