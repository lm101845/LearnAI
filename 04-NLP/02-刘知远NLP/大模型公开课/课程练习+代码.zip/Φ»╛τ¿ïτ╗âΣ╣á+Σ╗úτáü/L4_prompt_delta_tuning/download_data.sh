DATA_PATH="./data"

mkdir $DATA_PATH
cd $DATA_PATH
wget  https://aristo-data-public.s3-us-west-2.amazonaws.com/arc-da/ARC-DA-v1.1.zip
unzip ARC-DA-v1.1.zip
